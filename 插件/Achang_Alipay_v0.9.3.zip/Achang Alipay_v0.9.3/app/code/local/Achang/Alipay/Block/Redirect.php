<?php
/**
 * Magento
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@magentocommerce.com so we can send you a copy immediately.
 */
/**
 * Created by  Achang WebDev
 * @copyright Achang WebDev
 * @link http://www.achang.com
 * @email magento@achang.com
 *
 * Date Time: 13-6-14 上午11:37
 */
class Achang_Alipay_Block_Redirect extends Mage_Core_Block_Abstract
{

    protected function _toHtml()
    {
        $alipay = Mage::getModel('alipay/payment');

        $service_type = $alipay->getConfigData('service_type');
        if($service_type == 'alipay.wap.auth.authAndExecute'){
            require_once("lib_wap/alipay_submit.class.php");
        }else{
            require_once("lib_web/alipay_submit.class.php");
        }


        /* *
         * 配置文件
         * 版本：3.3
         * 日期：2012-07-19
         * 说明：
         * 以下代码只是为了方便商户测试而提供的样例代码，商户可以根据自己网站的需要，按照技术文档编写,并非一定要使用该代码。
         * 该代码仅供学习和研究支付宝接口使用，只是提供一个参考。

         * 提示：如何获取安全校验码和合作身份者id
         * 1.用您的签约支付宝账号登录支付宝网站(www.alipay.com)
         * 2.点击“商家服务”(https://b.alipay.com/order/myorder.htm)
         * 3.点击“查询合作者身份(pid)”、“查询安全校验码(key)”

         * 安全校验码查看时，输入支付密码后，页面呈灰色的现象，怎么办？
         * 解决方法：
         * 1、检查浏览器配置，不让浏览器做弹框屏蔽设置
         * 2、更换浏览器或电脑，重新登录查询。
         */

//↓↓↓↓↓↓↓↓↓↓请在这里配置您的基本信息↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓
//合作身份者id，以2088开头的16位纯数字
        $alipay_config['partner']		= $alipay->getConfigData('partner_id');

//安全检验码，以数字和字母组成的32位字符
//如果签名方式设置为“MD5”时，请设置该参数
        $alipay_config['key']			= $alipay->getConfigData('security_code');

//商户的私钥（后缀是.pen）文件相对路径
//如果签名方式设置为“0001”时，请设置该参数
        $alipay_config['private_key_path']	= 'key/rsa_private_key.pem';

//支付宝公钥（后缀是.pen）文件相对路径
//如果签名方式设置为“0001”时，请设置该参数
        $alipay_config['ali_public_key_path']= 'key/alipay_public_key.pem';
       /** @var added by Minglong begin*/
        $order = $this->getOrder();
        if (!($order instanceof Mage_Sales_Model_Order)) {
            Mage::throwException($this->_getHelper()->__('Cannot retrieve order object'));
        }

        $currency_code = Mage::app()->getStore()->getCurrentCurrencyCode();
        $converted_final_price = Mage::helper('directory')->currencyConvert($order->getBaseGrandTotal(), $currency_code, 'CNY');
        if($converted_final_price){
            $converted_final_price=$converted_final_price;
        }else{
            $converted_final_price=$order->getBaseGrandTotal();
        }
        $WIDseller_email = $alipay->getConfigData('seller_email');
        $WIDout_trade_no = $order->getRealOrderId();
        $WIDsubject = $order->getRealOrderId();
        $WIDtotal_fee = sprintf('%.2f', $converted_final_price) ;

        /** @var added by Minglong  end*/
//↑↑↑↑↑↑↑↑↑↑请在这里配置您的基本信息↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑


//签名方式 不需修改
        $alipay_config['sign_type']    = 'MD5';

//字符编码格式 目前支持 gbk 或 utf-8
        $alipay_config['input_charset']= 'utf-8';

//ca证书路径地址，用于curl中ssl校验
//请保证cacert.pem文件在当前文件夹目录中
        $alipay_config['cacert']    = getcwd().'\\cacert.pem';

//访问模式,根据自己的服务器是否支持ssl访问，若支持请选择https；若不支持请选择http
        $alipay_config['transport']    = 'http';



        /**************************调用授权接口alipay.wap.trade.create.direct获取授权码token**************************/

//返回格式
        $format = "xml";
//必填，不需要修改

//返回格式
        $v = "2.0";
//必填，不需要修改

//请求号
        $req_id = date('Ymdhis');
//必填，须保证每次请求都是唯一

//**req_data详细信息**

//服务器异步通知页面路径
        $notify_url = Mage::getUrl('alipay/payment/notify/', array('_secure' => true));
//需http://格式的完整路径，不允许加?id=123这类自定义参数

//页面跳转同步通知页面路径
        $call_back_url = Mage::getUrl('checkout/onepage/success', array('_secure' => true));
//需http://格式的完整路径，不允许加?id=123这类自定义参数

//操作中断返回地址
        $merchant_url =  Mage::getUrl('alipay/payment/error', array('_secure' => true));
//用户付款中途退出返回商户的地址。需http://格式的完整路径，不允许加?id=123这类自定义参数

//卖家支付宝帐户
        $seller_email = $WIDseller_email;
//必填

//商户订单号
        $out_trade_no = $WIDout_trade_no;
//商户网站订单系统中唯一订单号，必填

//订单名称
        $subject = $WIDsubject;
//必填

//付款金额
        $total_fee = $WIDtotal_fee;
//必填
        if($service_type == 'alipay.wap.auth.authAndExecute'){
            //请求业务参数详细
            $req_data = '<direct_trade_create_req><notify_url>' . $notify_url . '</notify_url><call_back_url>' . $call_back_url . '</call_back_url><seller_account_name>' . $seller_email . '</seller_account_name><out_trade_no>' . $out_trade_no . '</out_trade_no><subject>' . $subject . '</subject><total_fee>' . $total_fee . '</total_fee><merchant_url>' . $merchant_url . '</merchant_url></direct_trade_create_req>';
//必填

            /************************************************************/

//构造要请求的参数数组，无需改动
            $para_token = array(
                "service" => "alipay.wap.trade.create.direct",
                "partner" => trim($alipay_config['partner']),
                "sec_id" => trim($alipay_config['sign_type']),
                "format"	=> $format,
                "v"	=> $v,
                "req_id"	=> $req_id,
                "req_data"	=> $req_data,
                "_input_charset"	=> trim(strtolower($alipay_config['input_charset']))
            );

//建立请求
            $alipaySubmit = new AlipaySubmit($alipay_config);
            $html_text = $alipaySubmit->buildRequestHttp($para_token);

//URLDECODE返回的信息
            $html_text = urldecode($html_text);

//解析远程模拟提交后返回的信息
            $para_html_text = $alipaySubmit->parseResponse($html_text);

//获取request_token
            $request_token = $para_html_text['request_token'];


            /**************************根据授权码token调用交易接口alipay.wap.auth.authAndExecute**************************/

//业务详细
            $req_data = '<auth_and_execute_req><request_token>' . $request_token . '</request_token></auth_and_execute_req>';
//必填

//构造要请求的参数数组，无需改动
            $parameter = array(
                "service" => $service_type,
                "partner" => trim($alipay_config['partner']),
                "sec_id" => trim($alipay_config['sign_type']),
                "format"	=> $format,
                "v"	=> $v,
                "req_id"	=> $req_id,
                "req_data"	=> $req_data,
                "_input_charset"	=> trim(strtolower($alipay_config['input_charset']))
            );
        }elseif($service_type == 'create_direct_pay_by_user'){
            //订单描述
            $body = $order->getRealOrderId();

            if($order->getData('alipay_pay_method') == 'bank'){
                //默认支付方式
                $paymethod = "bankPay";
                //默认网银
                $defaultbank = $order->getData('alipay_pay_bank');
            }else{
                $paymethod ='';
                $defaultbank='';
            }

            //商品展示地址
            $show_url = Mage::getUrl();
            //需以http://开头的完整路径，例如：http://www.xxx.com/myorder.html
            //防钓鱼时间戳
            $anti_phishing_key = "";
            //若要使用请调用类文件submit中的query_timestamp函数
            //客户端的IP地址
            $exter_invoke_ip = "";
            //非局域网的外网IP地址，如：221.0.0.1
            //支付类型
            $payment_type = "1";
            $parameter = array(
                "service" => $service_type,
                "partner" => trim($alipay_config['partner']),
                "payment_type"	=> $payment_type,
                "notify_url"	=> $notify_url,
                "return_url"	=> $call_back_url,
                "seller_email"	=> $seller_email,
                "out_trade_no"	=> $out_trade_no,
                "subject"	=> $subject,
                "total_fee"	=> $total_fee,
                "body"	=> $body,
                "show_url"	=> $show_url,
                "anti_phishing_key"	=> $anti_phishing_key,
                "exter_invoke_ip"	=> $exter_invoke_ip,
                "_input_charset"	=> trim(strtolower($alipay_config['input_charset']))
            );
            if($paymethod && $defaultbank){
                $parameter['paymethod'] = $paymethod;
                $parameter['defaultbank'] = $defaultbank;
            }
        }elseif('create_partner_trade_by_buyer' == $service_type){
            //支付类型
            $payment_type = "1";
            //订单描述
            $body = $order->getRealOrderId();
            //商品展示地址
            $show_url = Mage::getUrl();
            //商品数量
            $quantity = "1";
            //必填，建议默认为1，不改变值，把一次交易看成是一次下订单而非购买一件商品
            //物流费用
            $logistics_fee = "0.00";
            //必填，即运费
            //物流类型
            $logistics_type = "EXPRESS";
            //必填，三个值可选：EXPRESS（快递）、POST（平邮）、EMS（EMS）
            //物流支付方式
            $logistics_payment = "SELLER_PAY";
            //必填，两个值可选：SELLER_PAY（卖家承担运费）、BUYER_PAY（买家承担运费）
        //构造要请求的参数数组，无需改动
        $parameter = array(
            "service" => "create_partner_trade_by_buyer",
            "partner" => trim($alipay_config['partner']),
            "payment_type"	=> $payment_type,
            "notify_url"	=> $notify_url,
            "return_url"	=> $call_back_url,
            "seller_email"	=> $seller_email,
            "out_trade_no"	=> $out_trade_no,
            "subject"	=> $subject,
            "price"	=> $total_fee,
            "quantity"	=> $quantity,
            "logistics_fee"	=> $logistics_fee,
            "logistics_type"	=> $logistics_type,
            "logistics_payment"	=> $logistics_payment,
            "body"	=> $body,
            "show_url"	=> $show_url,
//            "receive_name"	=> $receive_name,
//            "receive_address"	=> $receive_address,
//            "receive_zip"	=> $receive_zip,
//            "receive_phone"	=> $receive_phone,
//            "receive_mobile"	=> $receive_mobile,
            "_input_charset"	=> trim(strtolower($alipay_config['input_charset']))
        );
    }

//建立请求
        $alipaySubmit = new AlipaySubmit($alipay_config);
        $html_text = $alipaySubmit->buildRequestForm($parameter, 'get', '确认');
        return $html_text;
    }
}