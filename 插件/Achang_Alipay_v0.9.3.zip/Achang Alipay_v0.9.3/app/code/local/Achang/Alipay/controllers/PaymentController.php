<?php
/**
 * Magento
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@magentocommerce.com so we can send you a copy immediately.
 */
/**
 * Created by  Achang WebDev
 * @copyright Achang WebDev
 * @link http://www.achang.com
 * @email magento@achang.com
 *
 * Date Time: 13-6-14 上午11:37
 */
class Achang_Alipay_PaymentController extends Mage_Core_Controller_Front_Action
{
    /**
     * Order instance
     */
    protected $_order;

    /**
     *  Get order
     *
     * @param    none
     *
     * @return      Mage_Sales_Model_Order
     */
    public function getOrder()
    {
        if ($this->_order == null) {
            $session      = Mage::getSingleton('checkout/session');
            $this->_order = Mage::getModel('sales/order');
            $this->_order->loadByIncrementId($session->getLastRealOrderId());
        }
        return $this->_order;
    }

    /**
     * When a customer chooses Alipay on Checkout/Payment page
     *
     */
    public function redirectAction()
    {
        $session = Mage::getSingleton('checkout/session');
        $session->setAlipayPaymentQuoteId($session->getQuoteId());

        $order = $this->getOrder();

        if (!$order->getId()) {
            $this->norouteAction();
            return;
        }

        $order->addStatusToHistory(
            $order->getStatus(),
            Mage::helper('alipay')->__('Customer was redirected to Alipay')
        );
        $order->save();

        $this->getResponse()
            ->setBody(
                $this->getLayout()
                    ->createBlock('alipay/redirect')
                    ->setOrder($order)
                    ->toHtml()
            );

        $session->unsQuoteId();
    }

    public function notifyAction()
    {
        if ($this->getRequest()->isPost()) {
            $postData = $this->getRequest()->getPost();
            $method   = 'post';


        } else {
            if ($this->getRequest()->isGet()) {
                $postData = $this->getRequest()->getQuery();
                $method   = 'get';
            } else {
                return;
            }
        }

        $alipay = Mage::getModel('alipay/payment');
        $service_type = $alipay->getConfigData('service_type');

        $alipay_config['partner']		= $alipay->getConfigData('partner_id');
        $alipay_config['key']			= $alipay->getConfigData('security_code');
        $alipay_config['sign_type']    = strtoupper('MD5');
        $alipay_config['input_charset']= strtolower('utf-8');
        $alipay_config['cacert']    = getcwd().'\\cacert.pem';
        $alipay_config['transport']    = 'http';

        if($service_type == 'alipay.wap.auth.authAndExecute'){
            $alipay_config['private_key_path']	= 'key/rsa_private_key.pem';
            $alipay_config['ali_public_key_path']= 'key/alipay_public_key.pem';
            require_once("lib_wap/alipay_notify.class.php");
        }else{
            require_once("lib_web/alipay_notify.class.php");
        }
        //计算得出通知验证结果
        $alipayNotify = new AlipayNotify($alipay_config);
        $verify_result = $alipayNotify->verifyNotify();

        if($service_type == 'alipay.wap.auth.authAndExecute'){
            $notify_data =  $_POST['notify_data'];
            $doc = new DOMDocument();
            $doc->loadXML($notify_data);

            //商户订单号
            $out_trade_no = $doc->getElementsByTagName( "out_trade_no" )->item(0)->nodeValue;
            //支付宝交易号
            $trade_no = $doc->getElementsByTagName( "trade_no" )->item(0)->nodeValue;
            //交易状态
            $trade_status = $doc->getElementsByTagName( "trade_status" )->item(0)->nodeValue;
        }else{
            $trade_status =  $postData['trade_status'];
            $out_trade_no = $postData['out_trade_no'];
        }

        if ($verify_result) {
            if ($trade_status == 'WAIT_BUYER_PAY') { //等待买家付款

                $order = Mage::getModel('sales/order');
                $order->loadByIncrementId($out_trade_no);
                $order->addStatusToHistory(
                    $order->getStatus(),
                    Mage::helper('alipay')->__('等待买家付款。')
                );
                try {
                    $order->save();
                    echo "success";
                } catch (Exception $e) {

                }
            } else {
                if (
                    $trade_status == 'WAIT_SELLER_SEND_GOODS'
                    || $trade_status == 'TRADE_SUCCESS'
                ) { //买家付款成功,等待卖家发货

                    $order = Mage::getModel('sales/order');
                    $order->loadByIncrementId($out_trade_no);
                    //$order->setAlipayTradeno($postData['trade_no']);
                    // $order->sendNewOrderEmail();
                    $order->addStatusToHistory(
                        $alipay->getConfigData('order_status_payment_accepted'),
                        Mage::helper('alipay')->__('买家付款成功,等待卖家发货。')
                    );
                    try {
                        $order->save();
                        echo "success";
                    } catch (Exception $e) {
                        Mage::log($e->getMessage(), null, 'alipay.log', true);

                    }
                } else {
                    if ($trade_status == 'WAIT_BUYER_CONFIRM_GOODS') { //卖家已经发货等待买家确认

                        $order = Mage::getModel('sales/order');
                        $order->loadByIncrementId($out_trade_no);
                        //$order->setAlipayTradeno($postData['trade_no']);
                        // $order->sendNewOrderEmail();
                        $order->addStatusToHistory(
                            $alipay->getConfigData('order_status_payment_accepted'),
                            Mage::helper('alipay')->__('卖家已经发货等待买家确认。')
                        );
                        try {
                            $order->save();
                            echo "success";
                        } catch (Exception $e) {
                        }

                    } else {
                        if ($trade_status == 'TRADE_FINISHED') {
                            $order = Mage::getModel('sales/order');
                            $order->loadByIncrementId($out_trade_no);
                            //$order->setAlipayTradeno($postData['trade_no']);
                            $order->setStatus(Mage_Sales_Model_Order::STATE_PROCESSING);
                            // $order->sendNewOrderEmail();
                            $order->addStatusToHistory(
                                $alipay->getConfigData('order_status_payment_accepted'),
                                Mage::helper('alipay')->__('买家已付款,交易成功结束。')
                            );
                            try {
                                $order->save();
                                echo "success";
                            } catch (Exception $e) {

                            }

                        } else {
                            echo "fail";
                            Mage::log("x");
                        }
                    }
                }
            }

        } else {
            echo "fail";
        }
    }

    /**
     *  Save invoice for order
     *
     * @param    Mage_Sales_Model_Order $order
     *
     * @return      boolean Can save invoice or not
     */
    protected function saveInvoice(Mage_Sales_Model_Order $order)
    {
        if ($order->canInvoice()) {
            $convertor = Mage::getModel('sales/convert_order');
            $invoice   = $convertor->toInvoice($order);
            foreach ($order->getAllItems() as $orderItem) {
                if (!$orderItem->getQtyToInvoice()) {
                    continue;
                }
                $item = $convertor->itemToInvoiceItem($orderItem);
                $item->setQty($orderItem->getQtyToInvoice());
                $invoice->addItem($item);
            }
            $invoice->collectTotals();
            $invoice->register()->capture();
            Mage::getModel('core/resource_transaction')
                ->addObject($invoice)
                ->addObject($invoice->getOrder())
                ->save();
            return true;
        }

        return false;
    }

    /**
     *  Success payment page
     *
     * @param    none
     *
     * @return      void
     */
    public function successAction()
    {
        $session = Mage::getSingleton('checkout/session');
        $session->setQuoteId($session->getAlipayPaymentQuoteId());
        $session->unsAlipayPaymentQuoteId();

        $order = $this->getOrder();

        if (!$order->getId()) {
            $this->norouteAction();
            return;
        }

        $order->addStatusToHistory(
            $order->getStatus(),
            Mage::helper('alipay')->__('Customer successfully returned from Alipay')
        );

        $order->save();

        $this->_redirect('checkout/onepage/success');
    }

    /**
     *  Failure payment page
     *
     * @param    none
     *
     * @return      void
     */
    public function errorAction()
    {
        $session  = Mage::getSingleton('checkout/session');
        $errorMsg = Mage::helper('alipay')->__(' There was an error occurred during paying process.');

        $order = $this->getOrder();

        if (!$order->getId()) {
            $this->norouteAction();
            return;
        }
        if ($order instanceof Mage_Sales_Model_Order && $order->getId()) {
            $order->addStatusToHistory(
                Mage_Sales_Model_Order::STATE_CANCELED, //$order->getStatus(),
                Mage::helper('alipay')->__('Customer returned from Alipay.') . $errorMsg
            );

            $order->save();
        }

        $this->loadLayout();
        $this->renderLayout();
        Mage::getSingleton('checkout/session')->unsLastRealOrderId();
    }
}
