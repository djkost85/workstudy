<?php
/**
 * Magento
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@magentocommerce.com so we can send you a copy immediately.
 */
/**
 * Created by  Achang WebDev
 * @copyright Achang WebDev
 * @link http://www.achang.com
 *
 * Date Time: 13-6-14 上午11:37
 */
 
class Achang_Alipay_Model_Observer extends Varien_Object
{
    function saveOrder($observer){
        $order = $observer->getOrder();
        $data = Mage::app()->getRequest()->getParams();
        if(isset($data['payment']['alipay_pay_bank'])){
            $alipay_pay_bank = $data['payment']['alipay_pay_bank'];
            $order->setData('alipay_pay_method','bank');
            $order->setData('alipay_pay_bank',$alipay_pay_bank);
        }else{
            $order->setData('alipay_pay_method','alipay');
        }
        //$order->save();
        return $this;
    }
}