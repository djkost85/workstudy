<?php
/**
 * Created by  Achang WebDev
 *
 * @copyright Achang WebDev
 * @link http://www.achang.com
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 *
 */



class Achang_ChinaRegion_Model_Mysql4_Country_Collection extends Mage_Directory_Model_Mysql4_Country_Collection
{
	
	public function getLocaleCode()
	{	
		return Mage::app()->getLocale()->getLocaleCode();
	}

	/**
     * Join Region Table
     *
     * @return object
     */
    public function joinRegionTable()
    {
    	$this->_idFieldName = 'country_region';
        $this->_select->joinLeft(
            array('region_table' => Mage::getSingleton('core/resource')->getTableName('directory/country_region')),
            'main_table.country_id=region_table.country_id',
            array('region_code' => 'code','region_id'=>'region_id','region_default_name'=>'default_name')
        );
        $this->_select->joinLeft(
            array('region_name_table' => Mage::getSingleton('core/resource')->getTableName('directory/country_region_name')),
            'region_table.region_id=region_name_table.region_id and region_name_table.locale="'.$this->getLocaleCode().'"',
            array('region_name' => 'name')
        );
        $this->_select->joinLeft(
            array('region_cn_name' => Mage::getSingleton('core/resource')->getTableName('directory/country_region_name')),
            'region_table.region_id=region_cn_name.region_id and region_cn_name.locale="'.Achang_ChinaRegion_Helper_Data::CN_LOCALE.'"',
            array('region_chinese_name' => 'name')
        );
        $this->_select->joinLeft(
            array('region_en_name' => Mage::getSingleton('core/resource')->getTableName('directory/country_region_name')),
            'region_table.region_id=region_en_name.region_id and region_en_name.locale="'.Achang_ChinaRegion_Helper_Data::EN_LOCALE.'"',
            array('region_english_name' => 'name')
        );
        return $this;
    }
    
	/**
     * Join Region Table
     *
     * @return object
     */
    public function joinCityTable()
    {
    	$this->_idFieldName = 'country_region_city';
        $this->_select->joinLeft(
            array('city_table' => Mage::getSingleton('core/resource')->getTableName('chinaregion/country_region_city')),
            'region_table.region_id=city_table.region_id',
            array('city_code' => 'code','city_id'=>'city_id','city_default_name'=>'default_name')
        );
        $this->_select->joinLeft(
            array('city_name_table' => Mage::getSingleton('core/resource')->getTableName('chinaregion/country_region_city_name')),
            'city_table.city_id=city_name_table.city_id and city_name_table.locale="'.$this->getLocaleCode().'"',
            array('city_name' => 'name')
        );
        $this->_select->joinLeft(
            array('city_cn_name' => Mage::getSingleton('core/resource')->getTableName('chinaregion/country_region_city_name')),
            'city_table.city_id=city_cn_name.city_id and city_cn_name.locale="'.Achang_ChinaRegion_Helper_Data::CN_LOCALE.'"',
            array('city_chinese_name' => 'name')
        );
        $this->_select->joinLeft(
            array('city_en_name' => Mage::getSingleton('core/resource')->getTableName('chinaregion/country_region_city_name')),
            'city_table.city_id=city_en_name.city_id and city_en_name.locale="'.Achang_ChinaRegion_Helper_Data::EN_LOCALE.'"',
            array('city_english_name' => 'name')
        );
        return $this;
    }
    
	/**
     * Join Region Table
     *
     * @return object
     */
    public function joinDistrictTable()
    {
    	$this->_idFieldName = 'country_region_city_region';
        $this->_select->joinLeft(
            array('district_table' => Mage::getSingleton('core/resource')->getTableName('chinaregion/country_region_city_district')),
            'district_table.city_id=city_table.city_id',
            array('district_code' => 'code','district_id'=>'district_id','district_default_name'=>'default_name')
        );
        $this->_select->joinLeft(
            array('district_name_table' => Mage::getSingleton('core/resource')->getTableName('chinaregion/country_region_city_district_name')),
            'district_table.district_id=district_name_table.district_id and district_name_table.locale="'.$this->getLocaleCode().'"',
            array('district_name' => 'name')
        );
        $this->_select->joinLeft(
            array('district_cn_name' => Mage::getSingleton('core/resource')->getTableName('chinaregion/country_region_city_district_name')),
            'district_table.district_id=district_cn_name.district_id and district_cn_name.locale="'.Achang_ChinaRegion_Helper_Data::CN_LOCALE.'"',
            array('district_chinese_name' => 'name')
        );
        $this->_select->joinLeft(
            array('district_en_name' => Mage::getSingleton('core/resource')->getTableName('chinaregion/country_region_city_district_name')),
            'district_table.district_id=district_en_name.district_id and district_en_name.locale="'.Achang_ChinaRegion_Helper_Data::EN_LOCALE.'"',
            array('district_english_name' => 'name')
        );
        return $this;
    }
    
}
