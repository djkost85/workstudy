<?php
/**
 * Created by  Achang WebDev
 *
 * @copyright Achang WebDev
 * @link http://www.achang.com
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 *
 */



class Achang_ChinaRegion_Block_Adminhtml_Region extends Mage_Adminhtml_Block_Widget_Grid_Container
{
    public function __construct()
    {
        $this->_controller  = 'adminhtml_chinaregion_index';
        $this->_headerText  = Mage::helper('chinaregion')->__('Manage China Region');
        $this->_blockGroup = 'chinaregion';
       
        parent::__construct();
    }

    protected function _prepareLayout()
    {
        /* Update default add button to add country button */
        $this->_updateButton('add', 'label', Mage::helper('core')->__('Create State/Province'));
        $this->_updateButton('add', 'onclick', "setLocation('".$this->getUrl('*/*/newState')."')");
        
        /* Add city button */
        $this->_addButton('add_city', array(
            'label'     => Mage::helper('core')->__('Create City'),
            'onclick'   => 'setLocation(\'' . $this->getUrl('*/*/newCity') .'\')',
            'class'     => 'add',
        ));

        /* Add district button */
        $this->_addButton('add_district', array(
            'label'     => Mage::helper('core')->__('Create District'),
            'onclick'   => 'setLocation(\'' . $this->getUrl('*/*/newDistrict') .'\')',
            'class'     => 'add',
        ));

        return parent::_prepareLayout();
    }

}
