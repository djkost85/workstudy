<?php
/**
 * Created by  Achang WebDev
 *
 * @copyright Achang WebDev
 * @link http://www.achang.com
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 *
 */

class Achang_ChinaRegion_Model_District extends Mage_Core_Model_Abstract
{
    protected function _construct()
    {
        $this->_init('chinaregion/district');
    }

    /**
     * Retrieve region name
     *
     * If name is no declared, then default_name is used
     *
     * @return string
     */
    public function getName()
    {
        $name = $this->getData('name');
        if (is_null($name)) {
            $name = $this->getData('default_name');
        }
        return $name;
    }

    public function loadByCode($code, $cityId)
    {
        if ($code) {
            $this->_getResource()->loadByCode($this, $code, $cityId);
        }
        return $this;
    }

    public function loadByName($name, $regionId)
    {
        $this->_getResource()->loadByName($this, $name, $regionId);
        return $this;
    }
    
	public function save()
    {	
    	$this->getResource()->save($this);
    	return $this;
    }
    
    public function getCityModel()
    {
    	return Mage::getModel('chinaregion/city')->load($this->getCityId());
    }
    
	public function delete()
    {
    	$this->getResource()->delete($this);
    	return $this;
    }

}
