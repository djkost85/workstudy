<?php
/**
 * Created by  Achang WebDev
 *
 * @copyright Achang WebDev
 * @link http://www.achang.com
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 *
 */


$installer = $this;
/* @var $installer Mage_Core_Model_Resource_Setup */

$installer = $this;
$installer->startSetup();
$installer->getConnection()->addColumn(
    $installer->getTable('sales_flat_order_address'),
    'district_id',
    "VARCHAR(255) DEFAULT NULL"
);
$installer->getConnection()->addColumn(
    $installer->getTable('sales_flat_quote_address'),
    'district_id',
    "VARCHAR(255) DEFAULT NULL"
);

$installer->getConnection()->addColumn(
    $installer->getTable('sales_flat_order_address'),
    'district',
    "VARCHAR(255) DEFAULT NULL"
);
$installer->getConnection()->addColumn(
    $installer->getTable('sales_flat_quote_address'),
    'district',
    "VARCHAR(255) DEFAULT NULL"
);

$installer->getConnection()->addColumn(
    $installer->getTable('sales_flat_order_address'),
    'city_id',
    "VARCHAR(255) DEFAULT NULL"
);
$installer->getConnection()->addColumn(
    $installer->getTable('sales_flat_quote_address'),
    'city_id',
    "VARCHAR(255) DEFAULT NULL"
);

$installer->endSetup();