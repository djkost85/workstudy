<?php
/**
 * Created by  Achang WebDev
 *
 * @copyright Achang WebDev
 * @link http://www.achang.com
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 *
 */


class Achang_ChinaRegion_Model_Mysql4_City_Collection extends Varien_Data_Collection_Db
{
    protected $_cityTable;
    protected $_cityNameTable;
    protected $_regionTable;

    public function __construct()
    {
        parent::__construct(Mage::getSingleton('core/resource')->getConnection('chinaregion_read'));

        $this->_regionTable    = Mage::getSingleton('core/resource')->getTableName('directory/country_region');
        $this->_cityTable     = Mage::getSingleton('core/resource')->getTableName('chinaregion/country_region_city');
        $this->_cityNameTable = Mage::getSingleton('core/resource')->getTableName('chinaregion/country_region_city_name');

        $locale = Mage::app()->getLocale()->getLocaleCode();

        $this->_select->from(array('city'=>$this->_cityTable),
            array('city_id'=>'city_id', 'region_id'=>'region_id', 'code'=>'code', 'default_name'=>'default_name')
        );
        $this->_select->joinLeft(array('cname'=>$this->_cityNameTable),
            "city.city_id=cname.city_id AND cname.locale='$locale'", array('name'));

        $this->setItemObjectClass(Mage::getConfig()->getModelClassName('chinaregion/city'));
    }

    public function addRegionFilter($regionId)
    {
        if (!empty($regionId)) {
            if (is_array($regionId)) {
                $this->addFieldToFilter('city.region_id', array('in'=>$regionId));
            } else {
                $this->addFieldToFilter('city.region_id', $regionId);
            }
        }
        return $this;
    }

    public function addRegionCodeFilter($regionCode)
    {
        $this->_select->joinLeft(array('region'=>$this->_regionTable), 'city.region_id=region.region_id');
        $this->_select->where("region.code = '{$regionCode}'");
        return $this;
    }

    public function addCityCodeFilter($cityCode)
    {
        if (!empty($cityCode)) {
            if (is_array($cityCode)) {
                $this->_select->where("city.code IN ('".implode("','", $cityCode)."')");
            } else {
                $this->_select->where("city.code = '{$cityCode}'");
            }
        }
        return $this;
    }

    public function addCityNameFilter($cityName)
    {
        if (!empty($cityName)) {
            if (is_array($cityName)) {
                $this->_select->where("city.default_name in ('".implode("','", $cityName)."')");
            } else {
                $this->_select->where("city.default_name = '{$cityName}'");
            }
        }
        return $this;
    }

    public function toOptionArray()
    {
        $options = array();
        foreach ($this as $item) {
            $options[] = array(
               'value' => $item->getId(),
               'label' => $item->getName()
            );
        }
        if (count($options)>0) {
            array_unshift($options, array('title'=>null, 'value'=>'0', 'label'=>Mage::helper('chinaregion')->__('-- Please select --')));
        }
        return $options;
    }
}
