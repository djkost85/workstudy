<?php
/**
 * Created by  Achang WebDev
 *
 * @copyright Achang WebDev
 * @link http://www.achang.com
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 *
 */



class Achang_ChinaRegion_Model_Mysql4_City
{
    protected $_cityTable;
    protected $_cityNameTable;

    /**
     * DB read connection
     *
     * @var Zend_Db_Adapter_Abstract
     */
    protected $_read;

    /**
     * DB write connection
     *
     * @var Zend_Db_Adapter_Abstract
     */
    protected $_write;

    public function __construct()
    {
        $resource = Mage::getSingleton('core/resource');
        $this->_cityTable     = $resource->getTableName('chinaregion/country_region_city');
        $this->_cityNameTable = $resource->getTableName('chinaregion/country_region_city_name');
        $this->_read    = $resource->getConnection('chinaregion_read');
        $this->_write   = $resource->getConnection('chinaregion_write');
    }

    public function getIdFieldName()
    {
        return 'city_id';
    }
    
	public function getMainTable()
    {
        return $this->_cityTable;
    }
    
    public function getNameTable()
    {
    	return $this->_cityNameTable;
    }

    public function load(Achang_ChinaRegion_Model_City $city, $cityId)
    {
        $locale = Mage::app()->getLocale()->getLocaleCode();
        $systemLocale = Mage::app()->getDistroLocaleCode();

        $select = $this->_read->select()
            ->from(array('city'=>$this->_cityTable))
            ->where('city.city_id=?', $cityId)
            ->joinLeft(array('cname'=>$this->_cityNameTable),
                'cname.city_id=city.city_id AND (cname.locale=\''.$locale.'\' OR cname.locale=\''.$systemLocale.'\')',
                array('name', new Zend_Db_Expr('CASE cname.locale WHEN \''.$systemLocale.'\' THEN 1 ELSE 0 END sort_locale')))
            ->order('sort_locale')
            ->limit(1);

        $city->setData($this->_read->fetchRow($select));
        return $this;
    }

    public function loadByCode(Achang_ChinaRegion_Model_City $city, $cityCode, $regionId)
    {
        $locale = Mage::app()->getLocale()->getLocaleCode();

        $select = $this->_read->select()
            ->from(array('city'=>$this->_cityTable))
            ->where('city.region_id=?', $regionId)
            ->where('city.code=?', $cityCode)
            ->joinLeft(array('cname'=>$this->_cityNameTable),
                'cname.city_id=city.city_id AND cname.locale=\''.$locale.'\'',
                array('name'));

        $city->setData($this->_read->fetchRow($select));
        return $this;
    }

    public function loadByName(Achang_ChinaRegion_Model_City $city, $cityName, $regionId)
    {
        $locale = Mage::app()->getLocale()->getLocaleCode();

        $select = $this->_read->select()
            ->from(array('region'=>$this->_cityTable))
            ->where('city.region_id=?', $regionId)
            ->where('city.default_name=?', $cityName)
            ->join(array('cname'=>$this->_cityNameTable),
                'cname.city_id=city.city_id AND cname.locale=\''.$locale.'\'',
                array('name'));

        $city->setData($this->_read->fetchRow($select));
        return $this;
    }
    
/**
     * Prepare data for save
     *
     * @param   Mage_Core_Model_Abstract $object
     * @return  array
     */
    protected function _prepareDataForSave(Mage_Core_Model_Abstract $object)
    {
        return $this->_prepareDataForTable($object, $this->getMainTable());
    }

    /**
     * Prepare data for passed table
     *
     * @param Varien_Object $object
     * @param string $table
     * @return array
     */
    protected function _prepareDataForTable(Varien_Object $object, $table)
    {
        $data = array();
        $fields = $this->_getWriteAdapter()->describeTable($table);
        foreach (array_keys($fields) as $field) {
            if ($object->hasData($field)) {
                $fieldValue = $object->getData($field);
                if ($fieldValue instanceof Zend_Db_Expr) {
                    $data[$field] = $fieldValue;
                } else {
                    if (null !== $fieldValue) {
                        $data[$field] = $this->_prepareValueForSave($fieldValue, $fields[$field]['DATA_TYPE']);
                    } elseif (!empty($fields[$field]['NULLABLE'])) {
                        $data[$field] = null;
                    }
                }
            }
        }
        return $data;
    }
    
	/**
     * Prepare value for save
     *
     * @param mixed $value
     * @param string $type
     * @return mixed
     */
    protected function _prepareValueForSave($value, $type)
    {
        if ($type == 'decimal') {
            $value = Mage::app()->getLocale()->getNumber($value);
        }
        return $value;
    }
    
    /**
     * Perform actions after object save
     *
     * @param Varien_Object $object
     */
    protected function _afterSave(Mage_Core_Model_Abstract $object)
    {
    	if($object->getLocaleName()) {
	    	$localeCode = Mage::app()->getLocale()->getLocaleCode();
	    	$sql = "INSERT INTO {$this->getNameTable()} (`locale`,`{$this->getIdFieldName()}`,`name`) ".
	    		"VALUES('{$localeCode}',{$object->getId()},'{$object->getLocaleName()}') ".
	    		"ON DUPLICATE KEY UPDATE name=VALUES(name);";
	    	$this->_getWriteAdapter()->exec($sql);
    	}
    	if($object->getChineseLocaleName()) {
    		$sql = "INSERT INTO {$this->getNameTable()} (`locale`,`{$this->getIdFieldName()}`,`name`) ".
	    		"VALUES('zh_CN',{$object->getId()},'{$object->getChineseLocaleName()}') ".
	    		"ON DUPLICATE KEY UPDATE name=VALUES(name);";
	    	$this->_getWriteAdapter()->exec($sql);
    	}
    	if($object->getEnglishLocaleName()) {
    		$sql = "INSERT INTO {$this->getNameTable()} (`locale`,`{$this->getIdFieldName()}`,`name`) ".
	    		"VALUES('en_US',{$object->getId()},'{$object->getEnglishLocaleName()}') ".
	    		"ON DUPLICATE KEY UPDATE name=VALUES(name);";
	    	$this->_getWriteAdapter()->exec($sql);
    	}
    	return $this;
    }
    
    /**
     * Perform actions before object save
     *
     * @param Varien_Object $object
     */
	protected function _beforeSave(Mage_Core_Model_Abstract $object)
    {
    	return $this;
    }
    
	/**
     * Delete the object
     *
     * @param Varien_Object $object
     * @return Mage_Core_Model_Mysql4_Abstract
     */
    public function delete(Mage_Core_Model_Abstract $object)
    {
        $this->_getWriteAdapter()->delete(
            $this->getMainTable(),
            $this->_getWriteAdapter()->quoteInto($this->getIdFieldName().'=?', $object->getId())
        );
        
        return $this;
    }
    
    protected function _getWriteAdapter()
    {
    	return $this->_write;
    }
    
    
	public function save(Mage_Core_Model_Abstract $object)
    {	
    	if ($object->isDeleted()) {
            return $this->delete($object);
        }
        
        if (!is_null($object->getId())) {
            $condition = $this->_getWriteAdapter()->quoteInto($this->getIdFieldName().'=?', $object->getId());
            
        	$select = $this->_getWriteAdapter()->select()
                    ->from($this->getMainTable(), array($this->getIdFieldName()))
                    ->where($condition);
            if ($this->_getWriteAdapter()->fetchOne($select) !== false) {
                $this->_getWriteAdapter()->update($this->getMainTable(), $this->_prepareDataForSave($object), $condition);
            } else {
                $this->_getWriteAdapter()->insert($this->getMainTable(), $this->_prepareDataForSave($object));
                $object->setId($this->_getWriteAdapter()->lastInsertId($this->getMainTable()));
            }
            
        } else {
            $this->_getWriteAdapter()->insert($this->getMainTable(), $this->_prepareDataForSave($object));
            $object->setId($this->_getWriteAdapter()->lastInsertId($this->getMainTable()));
            
        }

        $this->_afterSave($object);

        return $this;
    }
}
