<?php
/**
 * Created by  Achang WebDev
 *
 * @copyright Achang WebDev
 * @link http://www.achang.com
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 *
 */


class Achang_ChinaRegion_Block_Adminhtml_Chinaregion_Index_Grid extends Mage_Adminhtml_Block_Widget_Grid
{

    public function __construct()
    {
        parent::__construct();
        $this->setDefaultSort('country_id');
        $this->setDefaultDir('asc');
        $this->setId('region_grid');
        $this->setSaveParametersInSession(true);
    }

    protected function _prepareCollection()
    {
        $chinaregionCollection = Mage::getModel('directory/country')->getCollection()
            ->joinRegionTable()
            ->joinCityTable()
            ->joinDistrictTable()
            ->addCountryCodeFilter('CN');

        $this->setCollection($chinaregionCollection);
        return parent::_prepareCollection();
    }

    protected function _prepareColumns()
    {
        $this->addColumn('country_id', array(
            'header'        => Mage::helper('chinaregion')->__('Country'),
            'type'          => 'country',
            'align'         => 'left',
            'index'         => 'country_id',
            'filter_index'  => 'main_table.country_id',
            'renderer'      => 'chinaregion/adminhtml_grid_renderer_country',
//            'sortable'      => false
        ));

        $this->addColumn('region_name', array(
            'header'        => Mage::helper('chinaregion')->__('State/Region'),
            'header_export' => Mage::helper('chinaregion')->__('State'),
            'align'         =>'left',
            'index'         => 'region_name',
        	'default_index' => 'region_default_name',
            'filter_index'  => 'region_table.default_name',
        	'renderer'      => 'chinaregion/adminhtml_grid_renderer_region',
//            'default'       => '*',
        ));
        
        $this->addColumn('city_name', array(
            'header'        => Mage::helper('chinaregion')->__('City'),
            'header_export' => Mage::helper('chinaregion')->__('City'),
            'align'         =>'left',
            'index'         => 'city_name',
        	'default_index' => 'city_default_name',
            'filter_index'  => 'city_table.default_name',
        	'renderer'      => 'chinaregion/adminhtml_grid_renderer_city',
//            'default'       => '*',
        ));
        
        $this->addColumn('district_name', array(
            'header'        => Mage::helper('chinaregion')->__('District'),
            'header_export' => Mage::helper('chinaregion')->__('District'),
            'align'         =>'left',
            'index'         => 'district_name',
        	'default_index' => 'district_default_name',
            'filter_index'  => 'district_table.default_name',
        	'renderer'      => 'chinaregion/adminhtml_grid_renderer_district',
//            'default'       => '*',
        ));
        
        $this->addExportType('*/*/exportCsv', Mage::helper('chinaregion')->__('CSV'));
//        $this->addExportType('*/*/exportXml', Mage::helper('chinaregion')->__('XML'));

        return parent::_prepareColumns();
    }

//    public function getRowUrl($row)
//    {
//        return $this->getUrl('*/*/edit', array('rate' => $row->getTaxCalculationRateId()));
//    }

}

