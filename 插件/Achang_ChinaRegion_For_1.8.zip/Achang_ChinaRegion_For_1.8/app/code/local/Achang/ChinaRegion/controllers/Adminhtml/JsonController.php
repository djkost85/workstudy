<?php
require_once('Mage/Adminhtml/controllers/JsonController.php');
class Achang_ChinaRegion_Adminhtml_JsonController extends Mage_Adminhtml_JsonController
{
    public function countryRegionCityAction()
    {
        $arrRes = array();

        $regionId= $this->getRequest()->getParam('parent');
        $arrRegions= Mage::getResourceModel('chinaregion/city_collection')
            ->addRegionFilter($regionId)
            ->setOrder('city.code', 'ASC')
            ->load()
            ->toOptionArray();

        if (!empty($arrRegions)) {
            foreach ($arrRegions as $region) {
                $arrRes[] = $region;
            }
        }

        $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($arrRes));
    }
}
