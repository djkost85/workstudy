<?php
/**
 * Created by  Achang WebDev
 *
 * @copyright Achang WebDev
 * @link http://www.achang.com
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 *
 */


class Achang_ChinaRegion_Block_Adminhtml_Chinaregion_Index_Export extends Achang_ChinaRegion_Block_Adminhtml_Chinaregion_Index_Grid
{
    protected function _prepareColumns()
    {
        $this->addColumn('country_id', array(
            'header'        => Mage::helper('chinaregion')->__('Country'),
            'type'          => 'country',
            'align'         => 'left',
            'index'         => 'country_id',
            'filter_index'  => 'main_table.country_id',
            'renderer'      => 'chinaregion/adminhtml_grid_renderer_country',
//            'sortable'      => false
        ));

        $this->addColumn('region_code', array(
            'header_export' => Mage::helper('chinaregion')->__('Province Code'),
            'index'         => 'region_code',
        ));
        $this->addColumn('region_default_name', array(
            'header_export' => Mage::helper('chinaregion')->__('Province Default Name'),
            'index'         => 'region_default_name',
        ));
        $this->addColumn('region_chinese_name', array(
            'header_export' => Mage::helper('chinaregion')->__('Province Chinese Name'),
            'index'         => 'region_chinese_name',
        ));
        $this->addColumn('region_english_name', array(
            'header_export' => Mage::helper('chinaregion')->__('Province English Name'),
            'index'         => 'region_english_name',
        ));
        
        $this->addColumn('city_code', array(
            'header_export' => Mage::helper('chinaregion')->__('City Code'),
            'index'         => 'city_code',
        ));
        $this->addColumn('city_default_name', array(
            'header_export' => Mage::helper('chinaregion')->__('City Default Name'),
            'index'         => 'city_default_name',
        ));
        $this->addColumn('city_chinese_name', array(
            'header_export' => Mage::helper('chinaregion')->__('City Chinese Name'),
            'index'         => 'city_chinese_name',
        ));
        $this->addColumn('city_english_name', array(
            'header_export' => Mage::helper('chinaregion')->__('City English Name'),
            'index'         => 'city_english_name',
        ));
        
        $this->addColumn('district_code', array(
            'header_export' => Mage::helper('chinaregion')->__('District Code'),
            'index'         => 'district_code',
        ));
        $this->addColumn('district_default_name', array(
            'header_export' => Mage::helper('chinaregion')->__('District Default Name'),
            'index'         => 'district_default_name',
        ));
        $this->addColumn('district_chinese_name', array(
            'header_export' => Mage::helper('chinaregion')->__('District Chinese Name'),
            'index'         => 'district_chinese_name',
        ));
        $this->addColumn('district_english_name', array(
            'header_export' => Mage::helper('chinaregion')->__('District English Name'),
            'index'         => 'district_english_name',
        ));

        return $this;
    }

}

