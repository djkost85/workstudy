<?php
/**
 * Created by  Achang WebDev
 *
 * @copyright Achang WebDev
 * @link http://www.achang.com
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 *
 */



class Achang_ChinaRegion_Model_Mysql4_Address_Attribute_Backend_District extends Mage_Eav_Model_Entity_Attribute_Backend_Abstract
{
    public function beforeSave($object)
    {
        $field = $object->getData('district');
        if (is_numeric($field)) {
            $model = Mage::getModel('chinaregion/district')->load($field);
            if ($model->getId() && $object->getCityId() == $model->getCityId()) {
                $object->setDistrictId($model->getId())
                    ->setDistrict($model->getName());
            }
        }
        return $this;
    }
}
