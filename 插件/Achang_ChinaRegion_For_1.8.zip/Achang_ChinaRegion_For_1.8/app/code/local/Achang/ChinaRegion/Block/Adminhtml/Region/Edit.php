<?php
/**
 * Created by  Achang WebDev
 *
 * @copyright Achang WebDev
 * @link http://www.achang.com
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 *
 */



class Achang_ChinaRegion_Block_Adminhtml_Region_Edit extends Mage_Adminhtml_Block_Widget_Form_Container
{
    /**
     * Init class
     *
     */
    public function __construct()
    {
        switch (Mage::registry('region_type')) {
            case 'region':
                $this->_objectId = 'region_id';
                $saveLabel   = Mage::helper('chinaregion')->__('Save Region');
                $deleteLabel = Mage::helper('chinaregion')->__('Delete Region');
                $deleteUrl   = $this->getUrl('*/*/deleteRegion', array('item_id' => Mage::registry('region_data')->getId()));
                break;
            case 'city':
                $this->_objectId = 'city_id';
                $saveLabel   = Mage::helper('chinaregion')->__('Save City');
                $deleteLabel = Mage::helper('chinaregion')->__('Delete City');
                $deleteUrl   = $this->getUrl('*/*/deleteCity', array('item_id' => Mage::registry('region_data')->getId()));
                break;
            case 'district':
                $this->_objectId = 'district_id';
                $saveLabel   = Mage::helper('chinaregion')->__('Save District');
                $deleteLabel = Mage::helper('chinaregion')->__('Delete District');
                $deleteUrl   = $this->getUrl('*/*/deleteDistrict', array('item_id' => Mage::registry('region_data')->getId()));
                break;
        }
        $this->_controller = 'adminhtml_chinaregion_index';
        $this->_blockGroup = 'chinaregion';

        parent::__construct();

        $this->_updateButton('save', 'label', $saveLabel);
        $this->_updateButton('delete', 'label', $deleteLabel);
        $onclick = 'deleteConfirm(\''. Mage::helper('adminhtml')->__('Are you sure you want to do this?')
                    .'\', \'' . $deleteUrl . '\')';
        $this->_updateButton('delete', 'onclick', $onclick);
        
    }

    /**
     * Get Header text
     *
     * @return string
     */
    public function getHeaderText()
    {
        switch (Mage::registry('region_type')) {
            case 'region':
                $editLabel = Mage::helper('chinaregion')->__('Edit State/Province');
                $addLabel  = Mage::helper('chinaregion')->__('New State/Province');
                break;
            case 'city':
                $editLabel = Mage::helper('chinaregion')->__('Edit City');
                $addLabel  = Mage::helper('chinaregion')->__('New City');
                break;
            case 'district':
                $editLabel = Mage::helper('chinaregion')->__('Edit District');
                $addLabel  = Mage::helper('chinaregion')->__('New District');
                break;
        }

        return Mage::registry('store_action') == 'add' ? $addLabel : $editLabel;
    }
}
