<?php
/**
 * @category    Achang
 * @package     Achang_ChinaRegion
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */


class Achang_ChinaRegion_Adminhtml_Region_IndexController extends Mage_Adminhtml_Controller_Action
{
	/**
     * Initialize action
     *
     * @return Mage_Adminhtml_Controller_Action
     */
    protected function _initAction()
    {
        $this->loadLayout()
            ->_setActiveMenu('system/achang_chinaregion')
            ->_addBreadcrumb(Mage::helper('adminhtml')->__('System'), Mage::helper('adminhtml')->__('System'))
            ->_addBreadcrumb(Mage::helper('chinaregion')->__('Manage China Region'), Mage::helper('chinaregion')->__('Manage China Region'));
        return $this;
    }

    /**
     * Show Main Grid
     *
     */
    public function indexAction()
    {
        $this->_title($this->__('Manage China Region'));

        $this->_initAction()
            ->_addContent($this->getLayout()->createBlock('chinaregion/adminhtml_region', 'chinaregion_grid'))
            ->renderLayout();
    }

    /**
     * Add state/province
     */
	public function newStateAction()
	{
		Mage::register('region_type', 'region');
        $this->_forward('newDistrict');

	}

    public function newCityAction()
    {
        Mage::register('region_type', 'city');
        $this->_forward('newDistrict');
    }

    public function newDistrictAction()
    {
        if (!Mage::registry('region_type')) {
            Mage::register('region_type', 'district');
        }
        Mage::register('region_action', 'add');
        $this->_forward('editRegion');
    }

	public function editCityAction()
	{
		Mage::register('region_type', 'city');
        $this->_forward('editRegion');
	}

	public function editDistrictAction()
	{
		Mage::register('region_type', 'district');
        $this->_forward('editRegion');
	}

	public function editRegionAction()
	{
		$this->_title($this->__('System'))
             ->_title($this->__('Regions'));
		$session = $this->_getSession();
        if ($session->getPostData()) {
            Mage::register('region_post_data', $session->getPostData());
            $session->unsPostData();
        }
        if (!Mage::registry('region_type')) {
        	if($this->getRequest()->getParam('region_id',null)) {
        		Mage::register('region_type', 'region');
        	}
        	elseif($this->getRequest()->getParam('city_id',null)) {
        		Mage::register('region_type', 'city');
        	}
        	elseif($this->getRequest()->getParam('district_id',null)) {
        		Mage::register('region_type', 'district');
        	}else {
            	Mage::register('region_type', 'region');
        	}
        }
        if (!Mage::registry('region_action')) {
            Mage::register('region_action', 'edit');
        }

        switch (Mage::registry('region_type')) {
            case 'region':
                $itemId     = $this->getRequest()->getParam('region_id', null);
                $model      = Mage::getModel('directory/region');
                $title      = Mage::helper('chinaregion')->__("Region");
                $notExists  = Mage::helper('chinaregion')->__("The region does not exist.");
                $codeBase   = false;
//                $codeBase   = Mage::helper('chinaregion')->__('Before modifying the region code please make sure that it is not used in index.php.');
                break;
            case 'city':
                $itemId     = $this->getRequest()->getParam('city_id', null);
                $model      = Mage::getModel('chinaregion/city');
                $title      = Mage::helper('chinaregion')->__("City");
                $notExists  = Mage::helper('chinaregion')->__("The city does not exist");
                $codeBase   = false;
                break;
            case 'district':
                $itemId     = $this->getRequest()->getParam('district_id', null);
                $model      = Mage::getModel('chinaregion/district');
                $title      = Mage::helper('chinaregion')->__("District");
                $notExists  = Mage::helper('chinaregion')->__("The district doesn't exist");
                $codeBase   = false;
//                $codeBase   = Mage::helper('chinaregion')->__('Before modifying the store view code please make sure that it is not used in index.php.');
                break;
            default:
            	$this->_redirect('*/*/');
            	return;
        }

        if (null !== $itemId) {
            $model->load($itemId);
        }

        if ($model->getId() || Mage::registry('region_action') == 'add') {
            Mage::register('region_data', $model);

            if (Mage::registry('region_action') == 'add') {
                $this->_title($this->__('New ') . $title);
            }
            else {
                $this->_title($model->getName());
            }

            if (Mage::registry('region_action') == 'edit' && $codeBase && !$model->isReadOnly()) {
                $this->_getSession()->addNotice($codeBase);
            }

            $this->_initAction()
                ->_addContent($this->getLayout()->createBlock('chinaregion/adminhtml_region_edit'))
                ->renderLayout();
        }
        else {
            $session->addError($notExists);
            $this->_redirect('*/*/');
        }
	}

	public function deleteRegionAction()
	{
		Mage::register('region_type', 'region');
        $this->_forward('deleteDistrict');
	}

	public function deleteCityAction()
	{
		Mage::register('region_type', 'city');
        $this->_forward('deleteDistrict');
	}

	public function deleteDistrictAction()
	{
		if (!Mage::registry('region_type')) {
            Mage::register('region_type', 'district');
        }

        switch (Mage::registry('region_type')) {
            case 'region':
            	$model = Mage::getModel('directory/region');
            	break;
            case 'city':
                $model = Mage::getModel('chinaregion/city');
                break;
			case 'district':
             	$model = Mage::getModel('chinaregion/district');
            	break;
            default:
                $this->_redirect('*/*/');
                return;
        }
        if ($id = $this->getRequest()->getParam('item_id')) {
            $item = $model->load($id);
            try {
                $model->delete();
                $this->_getSession()->addSuccess($this->__('The item has been deleted.'));
            }
            catch (Exception $e) {
                $this->_getSession()->addError($e->getMessage());
            }
        }
        $this->getResponse()->setRedirect($this->getUrl('*/*/', array('store'=>$this->getRequest()->getParam('store'))));
	}

	public function saveAction()
    {
        if ($this->getRequest()->isPost() && $postData = $this->getRequest()->getPost()) {
            if (empty($postData['region_type']) || empty($postData['region_action'])) {
                $this->_redirect('*/*/');
                return;
            }
            $session = $this->_getSession();

            try {
                switch ($postData['region_type']) {
                    case 'region':
                        $regionModel = Mage::getModel('directory/region');
                        if ($postData['region']['region_id']) {
                            $regionModel->load($postData['region']['region_id']);
                        }
                        $regionModel->setData($postData['region']);
                        if ($postData['region']['region_id'] == '') {
                            $regionModel->setId(null);
                        }

                        $regionModel->save();
                        $session->addSuccess(Mage::helper('chinaregion')->__('The state/province has been saved.'));
                        break;

                    case 'city':
                        $cityModel = Mage::getModel('chinaregion/city');
                        if ($postData['city']['city_id']) {
                            $cityModel->load($postData['city']['city_id']);
                        }
                        $cityModel->setData($postData['city']);
                        if ($postData['city']['city_id'] == '') {
                            $cityModel->setId(null);
                        }

                        $cityModel->save();

                        Mage::dispatchEvent('city_save', array('city' => $cityModel));

                        $session->addSuccess(Mage::helper('chinaregion')->__('The city has been saved.'));
                        break;

                    case 'district':
                        $districtModel = Mage::getModel('chinaregion/district');
                        if ($postData['district']['district_id']) {
                            $districtModel->load($postData['district']['district_id']);
                        }
                        $districtModel->setData($postData['district']);
                        if ($postData['district']['district_id'] == '') {
                            $districtModel->setId(null);
                        }

                        $districtModel->save();

                        Mage::app()->reinitStores();

                        Mage::dispatchEvent('district_save', array('district'=>$districtModel));

                        $session->addSuccess(Mage::helper('chinaregion')->__('The store view has been saved'));
                        break;
                    default:
                        $this->_redirect('*/*/');
                        return;
                }
                $this->_redirect('*/*/');
                return;
            }
            catch (Mage_Core_Exception $e) {
                $session->addError($e->getMessage());
                $session->setPostData($postData);
            }
            catch (Exception $e) {
                $session->addException($e, Mage::helper('core')->__('An error occurred while saving. Please review the error log.'));
                $session->setPostData($postData);
            }
            $this->_redirectReferer();
            return;
        }
        $this->_redirect('*/*/');
    }

    /**
     * Export rates grid to CSV format
     *
     */
    public function exportCsvAction()
    {
        $fileName   = 'chinaRegion.csv';
        $content    = $this->getLayout()->createBlock('chinaregion/adminhtml_chinaregion_index_export')
            ->getCsvFile();

        $this->_prepareDownloadResponse($fileName, $content);
    }

    /**
     * Import and export Page
     *
     */
    public function importExportAction()
    {
        $this->_title($this->__('China Region'))
       		->_title($this->__('Import and Export China Region'));

        $this->loadLayout()
            ->_setActiveMenu('system/chinaregion')
            ->_addContent($this->getLayout()->createBlock('chinaregion/adminhtml_chinaregion_index_importExport'))
            ->renderLayout();
    }

    /**
     * import action from import/export tax
     *
     */
    public function importPostAction()
    {
        setlocale ( LC_ALL, 'zh_CN.UTF-8' ) ;
        if ($this->getRequest()->isPost() && !empty($_FILES['import_region_file']['tmp_name'])) {
            try {
                $this->_importRegions();

                Mage::getSingleton('adminhtml/session')->addSuccess(Mage::helper('chinaregion')->__('The tax rate has been imported.'));
            }
            catch (Mage_Core_Exception $e) {
                Mage::getSingleton('adminhtml/session')->addError($e->getMessage());
            }
            catch (Exception $e) {
                Mage::getSingleton('adminhtml/session')->addError(Mage::helper('chinaregion')->__('Invalid file upload attempt')." error:".$e->getMessage());
            }
        }
        else {
            Mage::getSingleton('adminhtml/session')->addError(Mage::helper('chinaregion')->__('Invalid file upload attempt')." No files.");
        }
        $this->_redirect('*/*/importExport');
    }

    protected function _importRegions()
    {
        $fileName   = $_FILES['import_region_file']['tmp_name'];
        $csvObject  = new Varien_File_Csv();
        $csvData = $csvObject->getData($fileName);

        /** checks columns */
        $csvFields  = array(
            0   => Mage::helper('chinaregion')->__('Country'),
            1   => Mage::helper('chinaregion')->__('Province Code'),
            2   => Mage::helper('chinaregion')->__('Province Default Name'),
            3   => Mage::helper('chinaregion')->__('Province Chinese Name'),
            4   => Mage::helper('chinaregion')->__('Province English Name'),
            5   => Mage::helper('chinaregion')->__('City Code'),
            6   => Mage::helper('chinaregion')->__('City Default Name'),
            7   => Mage::helper('chinaregion')->__('City Chinese Name'),
            8   => Mage::helper('chinaregion')->__('City English Name'),
            9   => Mage::helper('chinaregion')->__('District Code'),
            10   => Mage::helper('chinaregion')->__('District Default Name'),
            11   => Mage::helper('chinaregion')->__('District Chinese Name'),
            12   => Mage::helper('chinaregion')->__('District English Name')
        );

        if ($csvData[0] == $csvFields) {
            foreach ($csvData as $k => $v) {
                if ($k == 0) {
                    continue;
                }
                foreach($v as $vKey=>$vValue) {
                	$v[$vKey] = addslashes($vValue);
                }

                //end of file has more then one empty lines
                if (count($v) <= 1 && !strlen($v[0])) {
                    continue;
                }

                if (count($csvFields) != count($v)) {
                    Mage::getSingleton('adminhtml/session')->addError(Mage::helper('chinaregion')->__('Invalid file upload attempt')." Columns are not right");
                }

                $country = Mage::getModel('directory/country')->loadByCode($v[0], 'iso2_code');
                if (!$country->getId()) {
                    Mage::getSingleton('adminhtml/session')->addError(Mage::helper('chinaregion')->__('One of the country has invalid code.'));
                    unset($country);
                    continue;
                }

                $regionModel = Mage::getModel('directory/region')->loadByCode($v[1],$country->getId());
                if(!$regionModel->getId() && $v[1]) {
                	$regionModel->setData(array(
                		'country_id' => $country->getId(),
                		'code' => $v[1],
                		'default_name' => $v[2],
                		'chinese_locale_name' => $v[3],
                		'english_locale_name' => $v[4]
                	))->save();
                } elseif($v[1]) {
                    $regionModel->addData(array(
                		'country_id' => $country->getId(),
                		'code' => $v[1],
                		'default_name' => $v[2],
                		'chinese_locale_name' => $v[3],
                		'english_locale_name' => $v[4]
                	))->save();
                }

                if(!$regionModel->getId()) {
                	unset($country);
	                unset($regionModel);
                	continue;
                }
                $cityModel = Mage::getModel('chinaregion/city')->loadByCode($v[5],$regionModel->getId());
            	if(!$cityModel->getId() && $v[5]) {
                	$cityModel->setData(array(
                		'region_id' => $regionModel->getId(),
                		'code' => $v[5],
                		'default_name' => $v[6],
                		'chinese_locale_name' => $v[7],
                		'english_locale_name' => $v[8]
                	))->save();
                } elseif($v[5]) {
                    $cityModel->addData(array(
                		'region_id' => $regionModel->getId(),
                		'code' => $v[5],
                		'default_name' => $v[6],
                		'chinese_locale_name' => $v[7],
                		'english_locale_name' => $v[8]
                	))->save();
                }

                if(!$cityModel->getId()) {
                	unset($country);
	                unset($regionModel);
	                unset($cityModel);
                	continue;
                }
            	$districtModel = Mage::getModel('chinaregion/district')->loadByCode($v[9], $cityModel->getId());
            	if(!$districtModel->getId() && $v[9]) {
                	$districtModel->setData(array(
                		'city_id' => $cityModel->getId(),
                		'code' => $v[9],
                		'default_name' => $v[10],
                		'chinese_locale_name' => $v[11],
                		'english_locale_name' => $v[12]
                	))->save();
                } elseif($v[9]) {
                	$districtModel->addData(array(
                		'city_id' => $cityModel->getId(),
                		'code' => $v[9],
                		'default_name' => $v[10],
                		'chinese_locale_name' => $v[11],
                		'english_locale_name' => $v[12]
                	))->save();
                }
                unset($country);
                unset($regionModel);
                unset($cityModel);
                unset($districtModel);
            }
        }
        else {
            Mage::throwException(Mage::helper('chinaregion')->__('Invalid file format upload attempt'));
        }
    }

    /**
     * export action from import/export tax
     *
     */
    public function exportPostAction()
    {
    	$this->_redirect('*/*/exportCsv');
    	return;
    }

}
