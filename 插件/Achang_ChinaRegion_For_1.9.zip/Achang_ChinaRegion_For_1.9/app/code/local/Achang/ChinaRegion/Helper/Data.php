<?php
/**
 * Created by  Achang WebDev
 *
 * @copyright Achang WebDev
 * @link http://www.achang.com
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 *
 */



class Achang_ChinaRegion_Helper_Data extends Mage_Core_Helper_Abstract
{
    const CN_LOCALE = 'zh_CN';
    const EN_LOCALE = 'en_US';
    protected $_regionJson;
    protected $_cityJson;
    protected $_districtJson;
    /**
     * @var Mage_Directory_Model_Mysql4_Region_Collection
     */
    protected $_regionCollection;
    protected $_cityCollection;

    public function getChinaCountryId()
    {
        return 'CN';
        //$locale = Mage::app()->getLocale();
//    	$locale = Mage::getStoreConfig(Mage_Core_Model_Locale::XML_PATH_DEFAULT_LOCALE);
//    	$code = substr($locale,-2);
//    	$country = Mage::getModel('directory/country')->loadByCode($code);
//    	return $country->getCountryId();
    }

    public function getChinaLocalName()
    {
        return Mage::app()->getLocale()->getCountryTranslation('zh_CN');
    }

    public function getChinaLocaleCode()
    {
        return 'zh_CN';
    }

    public function getLocaleCode()
    {
        return Mage::app()->getLocale()->getLocaleCode();
    }

    /**
     * Retrieve cities data json
     *
     * @return string
     */
    public function getCityJson()
    {

        Varien_Profiler::start('TEST: ' . __METHOD__);
        if (!$this->_cityJson) {
            $cacheKey = 'DIRECTORY_CITIES_JSON_STORE' . Mage::app()->getStore()->getId();
            if (Mage::app()->useCache('config')) {
                $json = Mage::app()->loadCache($cacheKey);
            }
            if (empty($json)) {
                $regionIds = array();
                foreach ($this->getRegionCollection() as $region) {
                    $regionIds[] = $region->getRegionId();
                }
                $collection = Mage::getModel('chinaregion/city')->getResourceCollection()
                    ->addRegionFilter($regionIds)
                    ->setOrder('city.code', 'ASC')
                    ->load();
                $cities     = array();
                foreach ($collection as $city) {
                    if (!$city->getCityId()) {
                        continue;
                    }
                    $cities[$city->getRegionId()][$city->getCityId()] = array(
                        'code' => $city->getCode(),
                        'name' => $city->getName()
                    );
                }
                // foreach ($regionIds as $tempRegion) {
                    // $cities[$tempRegion][] = array(
                        // 'code' => 'other',
                        // 'name' => $this->__('other')
                    // );
                // }
                $json = Mage::helper('core')->jsonEncode($cities);

                if (Mage::app()->useCache('config')) {
                    Mage::app()->saveCache($json, $cacheKey, array('config'));
                }
            }
            $this->_cityJson = $json;
        }

        Varien_Profiler::stop('TEST: ' . __METHOD__);
        return $this->_cityJson;
    }

    /**
     * Retrieve cities data json
     *
     * @return string
     */
    public function getDistrictJson()
    {

        Varien_Profiler::start('TEST: ' . __METHOD__);
        if (!$this->_districtJson) {
            $cacheKey = 'DIRECTORY_DISTRICT_JSON_STORE' . Mage::app()->getStore()->getId();
            if (Mage::app()->useCache('config')) {
                $json = Mage::app()->loadCache($cacheKey);
            }
            if (empty($json)) {
                $cityIds = array();
                foreach ($this->getCityCollection() as $city) {
                    $cityIds[] = $city->getCityId();
                }
                $collection = Mage::getModel('chinaregion/district')->getResourceCollection()
                    ->addCityFilter($cityIds)
                    ->load();
                $dictricts  = array();
                foreach ($collection as $district) {
                    if (!$district->getCityId()) {
                        continue;
                    }
                    $dictricts[$district->getCityId()][$district->getDistrictId()] = array(
                        'code' => $district->getCode(),
                        'name' => $district->getName()
                    );
                }
                foreach ($cityIds as $tempCityId) {
                    $dictricts[$tempCityId][] = array(
                        'code' => 'other',
                        'name' => $this->__('other')
                    );
                }
                $json = Mage::helper('core')->jsonEncode($dictricts);

                if (Mage::app()->useCache('config')) {
                    Mage::app()->saveCache($json, $cacheKey, array('config'));
                }
            }
            $this->_districtJson = $json;
        }

        Varien_Profiler::stop('TEST: ' . __METHOD__);
        return $this->_districtJson;
    }

    public function getRegionCollection()
    {
        if (!$this->_regionCollection) {
            $this->_regionCollection = Mage::getModel('directory/region')->getResourceCollection()
//                ->addCountryFilter($this->getAddress()->getCountryId())
                ->setOrder('code', 'ASC')
                ->load();
        }
        return $this->_regionCollection;
    }

    /**
     * Retrieve regions data json
     *
     * @return string
     */
    public function getRegionJson()
    {
        if (!$this->_regionJson) {
            $cacheKey = 'DIRECTORY_REGIONS_JSON_STORE' . Mage::app()->getStore()->getId();
            if (Mage::app()->useCache('config')) {
                $json = Mage::app()->loadCache($cacheKey);
            }
            if (empty($json)) {
                $json  = Mage::helper('directory')->getRegionJson();
                $array = Mage::helper('core')->jsonDecode($json);
                if (isset($array['CN'])) {
                    $cn = array();
                    foreach ($array['CN'] as $k => $v) {
                        $cn[$v['code']] = $k;
                    }
                    ksort($cn);

                    $sorted = array();
                    foreach ($cn as $code => $k) {
                        $sorted[$k] = $array['CN'][$k];
                    }
                    $array['CN'] = $sorted;
                }
                $json = Mage::helper('core')->jsonEncode($array);

                if (Mage::app()->useCache('config')) {
                    Mage::app()->saveCache($json, $cacheKey, array('config'));
                }
            }
            $this->_regionJson = $json;
        }
        return $this->_regionJson;
    }

    public function getCityCollection()
    {
        if (!$this->_cityCollection) {
            $this->_cityCollection = Mage::getModel('chinaregion/city')->getResourceCollection()
//                ->addCountryFilter($this->getAddress()->getCountryId())
                ->load();


        }
        return $this->_cityCollection;
    }

    public function getDistrictCollection()
    {
        if (!$this->_districtCollection) {
            $this->_districtCollection = Mage::getModel('chinaregion/district')->getResourceCollection()
//                ->addCountryFilter($this->getAddress()->getCountryId())
                ->load();
        }
        return $this->_districtCollection;
    }

    /**
     * @return array(city_id=>city_name,...);
     */
    public function getCities()
    {
        $data = Mage::getResourceModel('chinaregion/city_collection')->load()->getData();
        foreach ($data as $v) {
            $cities[$v['city_id']] = $v['name'];
            if (empty($cities['name'])) {
                $cities[$v['city_id']] = $v['default_name'];
            }
        }
        return $cities;
    }
}
