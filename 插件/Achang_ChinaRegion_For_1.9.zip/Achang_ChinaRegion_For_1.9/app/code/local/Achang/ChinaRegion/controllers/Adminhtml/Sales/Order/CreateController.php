<?php
require_once('Mage/Adminhtml/controllers/Sales/Order/CreateController.php');
class Achang_ChinaRegion_Adminhtml_Sales_Order_CreateController extends Mage_Adminhtml_Sales_Order_CreateController
{
    /**
     * Saving quote and create order
     */
    public function saveAction()
    {
        try {
            $this->_processActionData('save');
            if ($paymentData = $this->getRequest()->getPost('payment')) {
                $this->_getOrderCreateModel()->setPaymentData($paymentData);
                $this->_getOrderCreateModel()->getQuote()->getPayment()->addData($paymentData);
            }


            $cities = Mage::helper('chinaregion')->getCities();
            $data = $this->getRequest()->getPost('order');
            $data['billing_address']['city_id'] = $data['billing_address']['city_ids'];
            if(!empty($data['billing_address']['city_ids']))
                $data['billing_address']['city'] = $cities[$data['billing_address']['city_ids']];

            $data['shipping_address'] = $data['billing_address'];

            $order = $this->_getOrderCreateModel()
                ->setIsValidate(true)
                ->importPostData($data)
                ->createOrder();

            $this->_getSession()->clear();
            Mage::getSingleton('adminhtml/session')->addSuccess($this->__('The order has been created.'));
            $this->_redirect('*/sales_order/view', array('order_id' => $order->getId()));
        } catch (Mage_Payment_Model_Info_Exception $e) {
            $this->_getOrderCreateModel()->saveQuote();
            $message = $e->getMessage();
            if( !empty($message) ) {
                $this->_getSession()->addError($message);
            }
            $this->_redirect('*/*/');
        } catch (Mage_Core_Exception $e){
            $message = $e->getMessage();
            if( !empty($message) ) {
                $this->_getSession()->addError($message);
            }
            $this->_redirect('*/*/');
        }
        catch (Exception $e){
            $this->_getSession()->addException($e, $this->__('Order saving error: %s', $e->getMessage()));
            $this->_redirect('*/*/');
        }
    }
}
