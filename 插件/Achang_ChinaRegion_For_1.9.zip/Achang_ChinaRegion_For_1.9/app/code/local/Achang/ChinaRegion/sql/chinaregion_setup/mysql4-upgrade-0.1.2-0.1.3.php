<?php
/**
 * Created by  Achang WebDev
 *
 * @copyright Achang WebDev
 * @link http://www.achang.com
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 *
 */


$installer = $this;
/* @var $installer Mage_Core_Model_Resource_Setup */

$installer = $this;
$installer->startSetup();

$installer->run("REPLACE INTO `directory_country_region` (`region_id`, `country_id`, `code`, `default_name`) VALUES
(515, 'CN', '120000', '天津市');

REPLACE INTO `directory_country_region_city` (`city_id`, `region_id`, `code`, `default_name`) VALUES
(343, 515, '120200', '县'),
(342, 515, '120100', '市辖区');

REPLACE INTO `directory_country_region_city_district` (`district_id`, `city_id`, `code`, `default_name`) VALUES
(3126, 342, '120101', '和平区'),
(3127, 342, '120102', '河东区'),
(3128, 342, '120103', '河西区'),
(3129, 342, '120104', '南开区'),
(3130, 342, '120105', '河北区'),
(3131, 342, '120106', '红桥区'),
(3132, 342, '120110', '东丽区'),
(3133, 342, '120111', '西青区'),
(3134, 342, '120112', '津南区'),
(3135, 342, '120113', '北辰区'),
(3136, 342, '120114', '武清区'),
(3137, 342, '120115', '宝坻区'),
(3138, 342, '120116', '滨海新区'),
(3139, 343, '120221', '宁河县'),
(3140, 343, '120223', '静海县'),
(3141, 343, '120225', '蓟县');

REPLACE INTO `directory_country_region_city_district_name` (`locale`, `district_id`, `name`) VALUES
('en_US', 3126, '和平区'),
('zh_CN', 3126, '和平区'),
('en_US', 3127, '河东区'),
('zh_CN', 3127, '河东区'),
('en_US', 3128, '河西区'),
('zh_CN', 3128, '河西区'),
('en_US', 3129, '南开区'),
('zh_CN', 3129, '南开区'),
('en_US', 3130, '河北区'),
('zh_CN', 3130, '河北区'),
('en_US', 3131, '红桥区'),
('zh_CN', 3131, '红桥区'),
('en_US', 3132, '东丽区'),
('zh_CN', 3132, '东丽区'),
('en_US', 3133, '西青区'),
('zh_CN', 3133, '西青区'),
('en_US', 3134, '津南区'),
('zh_CN', 3134, '津南区'),
('en_US', 3135, '北辰区'),
('zh_CN', 3135, '北辰区'),
('en_US', 3136, '武清区'),
('zh_CN', 3136, '武清区'),
('en_US', 3137, '宝坻区'),
('zh_CN', 3137, '宝坻区'),
('en_US', 3138, '滨海新区'),
('zh_CN', 3138, '滨海新区'),
('en_US', 3139, '宁河县'),
('zh_CN', 3139, '宁河县'),
('en_US', 3140, '静海县'),
('zh_CN', 3140, '静海县'),
('en_US', 3141, '蓟县'),
('zh_CN', 3141, '蓟县');

REPLACE INTO `directory_country_region_city_name` (`locale`, `city_id`, `name`) VALUES
('en_US', 342, '市辖区'),
('zh_CN', 342, '市辖区'),
('en_US', 343, '县'),
('zh_CN', 343, '县');

REPLACE INTO `directory_country_region_name` (`locale`, `region_id`, `name`) VALUES
('en_US', 515, '天津市'),
('zh_CN', 515, '天津市');
");

$installer->endSetup();