<?php
/**
 * Created by  Achang WebDev
 *
 * @copyright Achang WebDev
 * @link http://www.achang.com
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 *
 */

class Achang_ChinaRegion_Model_Region extends Mage_Directory_Model_Region
{
    public function save()
    {	
    	$this->getResource()->save($this);
    	return $this;
    }
    
    public function delete()
    {
    	$this->getResource()->delete($this);
    	return $this;
    }
}
