<?php
/**
 * Created by  Achang WebDev
 *
 * @copyright Achang WebDev
 * @link http://www.achang.com
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 *
 */


class Achang_ChinaRegion_Block_Adminhtml_Rewrite_Sales_Order_Create_Form_Address extends Mage_Adminhtml_Block_Sales_Order_Create_Form_Address{

    /**
     * Prepare Form and add elements to form
     *
     * @return Mage_Adminhtml_Block_Sales_Order_Create_Form_Address
     */
    protected function _prepareForm()
    {
        $fieldset = $this->_form->addFieldset('main', array(
            'no_container' => true
        ));

        /* @var $addressModel Mage_Customer_Model_Address */
        $addressModel = Mage::getModel('customer/address');

        $addressForm = $this->_getAddressForm()
            ->setEntity($addressModel);

        $attributes = $addressForm->getAttributes();

        //sort attributes
        $resortKey = array(
            'firstname',
            'company',
            'country_id',
            'region_id',
            'region',
            'city_ids',
            'district',
            'city_id',
            'city',
            'street',
            'telephone',
            'postcode',
            );
        foreach($resortKey as $v)
        {
            $sortFields[$v]=$attributes[$v];
            unset($attributes[$v]);
        }
        $attributes = array_merge($sortFields,$attributes);
        //sort attributes end
        
        if(isset($attributes['street'])) {
            Mage::helper('adminhtml/addresses')
                ->processStreetAttribute($attributes['street']);
        }
        $this->_addAttributesToForm($attributes, $fieldset);

        $prefixElement = $this->_form->getElement('prefix');
        if ($prefixElement) {
            $prefixOptions = $this->helper('customer')->getNamePrefixOptions($this->getStore());
            if (!empty($prefixOptions)) {
                $fieldset->removeField($prefixElement->getId());
                $prefixField = $fieldset->addField($prefixElement->getId(),
                    'select',
                    $prefixElement->getData(),
                    '^'
                );
                $prefixField->setValues($prefixOptions);
                if ($this->getAddressId()) {
                    $prefixField->addElementValues($this->getAddress()->getPrefix());
                }
            }
        }

        //$mobileConfig = 
                    //array(
                        //'name'      => 'Mobile',
                        //'label'     => $attribute->getFrontend()->getLabel(),
                        //'class'     => $attribute->getFrontend()->getClass(),
                        //'required'  => $attribute->getIsRequired(),
                        //'note'      => $attribute->getNote(),
                    //);
        
        //$this->_form->addField('mobile', 'text', $mobileConfig);
        //Zend_Debug::dump($this->_form);
        //Zend_Debug::dump(get_class_methods($this->_form));
        //exit;

        $suffixElement = $this->_form->getElement('suffix');
        if ($suffixElement) {
            $suffixOptions = $this->helper('customer')->getNameSuffixOptions($this->getStore());
            if (!empty($suffixOptions)) {
                $fieldset->removeField($suffixElement->getId());
                $suffixField = $fieldset->addField($suffixElement->getId(),
                    'select',
                    $suffixElement->getData(),
                    $this->_form->getElement('lastname')->getId()
                );
                $suffixField->setValues($suffixOptions);
                if ($this->getAddressId()) {
                    $suffixField->addElementValues($this->getAddress()->getSuffix());
                }
            }
        }


        $regionElement = $this->_form->getElement('region_id');
        if ($regionElement) {
            $regionElement->setNoDisplay(true);
        }

        $this->_form->setValues($this->getFormValues());

        if (!$this->_form->getElement('country_id')->getValue()) {
            $this->_form->getElement('country_id')->setValue(
                Mage::helper('core')->getDefaultCountry($this->getStore())
            );
        }

        return $this;
    }
}
