<?php
/**
 * Created by  Achang WebDev
 *
 * @copyright Achang WebDev
 * @link http://www.achang.com
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 *
 */



class Achang_ChinaRegion_Model_Mysql4_Address_Attribute_Source_City extends Mage_Eav_Model_Entity_Attribute_Source_Table
{
    public function getAllOptions()
    {
        if (!$this->_options) {
            $this->_options = Mage::getResourceModel('chinaregion/city_collection')->load()->toOptionArray();
        }
        return $this->_options;
    }
}
