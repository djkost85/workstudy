<?php
/**
 * Created by  Achang WebDev
 *
 * @copyright Achang WebDev
 * @link http://www.achang.com
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 *
 */



class Achang_ChinaRegion_Block_Adminhtml_Grid_Renderer_District extends Mage_Adminhtml_Block_Widget_Grid_Column_Renderer_Abstract
{
/**
     * Render column for export
     *
     * @param Varien_Object $row
     * @return string
     */
    public function renderExport(Varien_Object $row)
    {
        $value = $row->getData($this->getColumn()->getIndex());
    	if(!$value) {
    		$value = $row->getData($this->getColumn()->getDefaultIndex());
    	}
        return $value;
    }
    
    /**
     * Render district grid column
     *
     * @param   Varien_Object $row
     * @return  string
     */
    public function render(Varien_Object $row)
    {
    	$name = $this->renderExport($row);
    	if($name) {
    		$name = '<a title="'.Mage::helper('core')->__('Edit District').'" href="'.$this->getUrl('*/*/editDistrict', array('district_id'=>$row->getDistrictId())).'">' . $name . '</a>';
    	}
    	return $name;
    }
}
