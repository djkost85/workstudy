<?php
/**
 * Created by  Achang WebDev
 *
 * @copyright Achang WebDev
 * @link http://www.achang.com
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 *
 */


require_once 'Mage/Checkout/controllers/OnepageController.php';
class Achang_ChinaRegion_OnepageController extends Mage_Checkout_OnepageController
{


    /**
     * save checkout billing address
     */
    public function saveBillingAction()
    {
        if ($this->_expireAjax()) {
            return;
        }
        if ($this->getRequest()->isPost()) {
//            $postData = $this->getRequest()->getPost('billing', array());
//            $data = $this->_filterPostData($postData);
            $data = $this->getRequest()->getPost('billing', array());
            $data['district'] = null;

            if (!empty($data['district_id'])){
                $data['district'] = Mage::getModel('chinaregion/district')->load($data['district_id'])->getName();
            }

            if (!empty($data['city_id'])){
                $data['city'] = Mage::getModel('chinaregion/city')->load($data['city_id'])->getName();
            }

            $customerAddressId = $this->getRequest()->getPost('billing_address_id', false);

            if (isset($data['email'])) {
                $data['email'] = trim($data['email']);
            }
            $result = $this->getOnepage()->saveBilling($data, $customerAddressId);
            if (!isset($result['error'])) {
                /* check quote for virtual */
                if ($this->getOnepage()->getQuote()->isVirtual()) {
                    $result['goto_section'] = 'payment';
                    $result['update_section'] = array(
                        'name' => 'payment-method',
                        'html' => $this->_getPaymentMethodsHtml()
                    );
                } elseif (isset($data['use_for_shipping']) && $data['use_for_shipping'] == 1) {
                    $result['goto_section'] = 'shipping_method';
                    $result['update_section'] = array(
                        'name' => 'shipping-method',
                        'html' => $this->_getShippingMethodsHtml()
                    );

                    $result['allow_sections'] = array('shipping');
                    $result['duplicateBillingInfo'] = 'true';
                } else {
                    $result['goto_section'] = 'shipping';
                }
            }

            $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($result));
        }
    }

    /**
     * Shipping address save action
     */
    public function saveShippingAction()
    {
        if ($this->_expireAjax()) {
            return;
        }
        if ($this->getRequest()->isPost()) {
            $data = $this->getRequest()->getPost('shipping', array());
            $data['district'] = null;

            if (!empty($data['district_id'])){
                $data['district'] = Mage::getModel('chinaregion/district')->load($data['district_id'])->getName();
            }

            if (!empty($data['city_id'])){
                $data['city'] = Mage::getModel('chinaregion/city')->load($data['city_id'])->getName();
            }
            $customerAddressId = $this->getRequest()->getPost('shipping_address_id', false);
            $result = $this->getOnepage()->saveShipping($data, $customerAddressId);

            if (!isset($result['error'])) {
                $result['goto_section'] = 'shipping_method';
                $result['update_section'] = array(
                    'name' => 'shipping-method',
                    'html' => $this->_getShippingMethodsHtml()
                );
            }
            $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($result));
        }
    }
    public function getPostCodeAction()
    {
        $provinceId      = $this->getRequest()->getParam('province_id');
        $cityId          = $this->getRequest()->getParam('city_id');
        $districtId      = $this->getRequest()->getParam('district_id');
        $sql             = "select code from directory_country_region_city_district where district_id='$districtId'";
        $connection      = Mage::getModel('core/resource')->getConnection('core_write');
        $districtIdArray = $connection->fetchAll($sql);
        if (!empty($districtIdArray)) {
            $districtCode = $districtIdArray[0]['code'];
            $sql          = "select zip from directory_country_zipcode where areaid='$districtCode'";
            $zipArray     = $connection->fetchAll($sql);
            if (!empty($zipArray)) {
                $zip = $zipArray[0]['zip'];
                if (trim($zip)) {
                    echo $zip;
                }
            }
        }
        die();
    }
}
