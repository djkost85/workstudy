<?php
/**
 * Created by  Achang WebDev
 *
 * @copyright Achang WebDev
 * @link http://www.achang.com
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 *
 */



class Achang_ChinaRegion_Block_Adminhtml_Chinaregion_Index_Edit_Form extends Mage_Adminhtml_Block_Widget_Form
{

    /**
     * Class constructor
     *
     */
    public function __construct()
    {
        parent::__construct();
        $this->setId('regionForm');
    }

    /**
     * Prepare form data
     *
     * return Mage_Adminhtml_Block_Widget_Form
     */
    protected function _prepareForm()
    {
        if (Mage::registry('region_type') == 'region') {
            $model = Mage::registry('region_data');
            $showCountryFieldset = true;
            $showCityFieldset = $showDistrictFieldset = false;
        } elseif (Mage::registry('region_type') == 'city') {
            $model = Mage::registry('region_data');
            $showCityFieldset = true;
            $showCountryFieldset = $showDistrictFieldset = false;
        } elseif (Mage::registry('region_type') == 'district') {
            $model = Mage::registry('region_data');
            $showCountryFieldset = $showCityFieldset = false;
            $showDistrictFieldset = true;
        }

        $form = new Varien_Data_Form(array(
            'id'        => 'edit_form',
            'action'    => $this->getData('action'),
            'method'    => 'post'
        ));

        $countryId = Mage::helper('chinaregion')->getChinaCountryId();
        $optionsCountry = Mage::getModel('directory/country')->getCollection()
            	->addCountryIdFilter($countryId)
            	->toOptionArray();
        $localeCode = Mage::app()->getLocale()->getLocaleCode();
        if ($showCountryFieldset) {
            if ($postData = Mage::registry('region_post_data')) {
                $model->setData($postData['region']);
            }
            $fieldset = $form->addFieldset('regrion_fieldset', array(
                'legend' => Mage::helper('chinaregion')->__('State/Province Information')
            ));
            /* @var $fieldset Varien_Data_Form */

            
            //array_unshift($groups, array('label'=>'', 'value'=>0));
            $fieldset->addField('country_id', 'select', array(
                    'name'      => 'region[country_id]',
                    'label'     => Mage::helper('core')->__('Country'),
                    'value'     => Mage::helper('chinaregion')->getChinaCountryId(),
                    'values'    => $optionsCountry,
                    'required'  => true,
                    'disabled'  => false,
            ));
                
            $fieldset->addField('code', 'text', array(
                'name'      => 'region[code]',
                'label'     => Mage::helper('core')->__('Code'),
                'value'     => $model->getCode(),
                'required'  => true,
                'disabled'  => false,
            ));
            
            $fieldset->addField('default_name', 'text', array(
                'name'      => 'region[default_name]',
                'label'     => Mage::helper('core')->__('Default Name'),
                'value'     => $model->getDefaultName(),
                'required'  => true,
                'disabled'  => false,
            ));
            
            $fieldset->addField('locale_name', 'text', array(
                'name'      => 'region[locale_name]',
                'label'     => Mage::helper('core')->__('Locale Name').'('.$localeCode.')',
                'value'     => $model->getName(),
                'required'  => true,
                'disabled'  => false,
            ));

            $fieldset->addField('region_id', 'hidden', array(
                'name'  => 'region[region_id]',
                'value' => $model->getId()
            ));
        }

        $optionsRegion = Mage::getModel('directory/region')
                	->getCollection()
                	->addCountryFilter($countryId)
                	->toOptionArray();
        if ($showCityFieldset) {
            if ($postData = Mage::registry('region_post_data')) {
                $model->setData($postData['city']);
            }
            $fieldset = $form->addFieldset('city_fieldset', array(
                'legend' => Mage::helper('core')->__('City Information')
            ));
            
            $fieldset->addField('region_id', 'select', array(
                    'name'      => 'city[region_id]',
                    'label'     => Mage::helper('chinaregion')->__('Stage/Province'),
                    'value'     => $model->getRegionId(),
                    'values'    => $optionsRegion,
                    'required'  => true,
                    'disabled'  => false,
            ));

            $fieldset->addField('code', 'text', array(
                'name'      => 'city[code]',
                'label'     => Mage::helper('core')->__('Code'),
                'value'     => $model->getCode(),
                'required'  => true,
                'disabled'  => false,
            ));

            $fieldset->addField('default_name', 'text', array(
                'name'      => 'city[default_name]',
                'label'     => Mage::helper('chinaregion')->__('Default Name'),
                'value'     => $model->getDefaultName(),
                'required'  => true,
                'disabled'  => false,
            ));

            $fieldset->addField('locale_name', 'text', array(
                'name'      => 'city[locale_name]',
                'label'     => Mage::helper('core')->__('Locale Name').'('.$localeCode.')',
                'value'     => $model->getName(),
                'required'  => true,
                'disabled'  => false,
            ));

            $fieldset->addField('city_id', 'hidden', array(
                'name'      => 'city[city_id]',
                'no_span'   => true,
                'value'     => $model->getId()
            ));
        }

        if ($showDistrictFieldset) {
            if ($postData = Mage::registry('region_post_data')) {
                $model->setData($postData['district']);
            }
            $fieldset = $form->addFieldset('district_fieldset', array(
                'legend' => Mage::helper('chinaregion')->__('District Information')
            ));
			
        	$regions = Mage::getModel('directory/region')->getCollection()->addCountryFilter($countryId);
            $cities = Mage::getModel('chinaregion/city')->getCollection();
            $optionsCity = array();
            foreach ($regions as $region) {
            	$values = array();
                foreach ($cities as $city) {
                    if ($city->getRegionId() == $region->getId()) {
                        $values[] = array('label'=>$city->getName(),'value'=>$city->getId());
                    }
                }
                $optionsCity[] = array('label'=>$region->getName(),'value'=>$values);
            }
			
            
            $fieldset->addField('city_id', 'select', array(
                'name'      => 'district[city_id]',
                'label'     => Mage::helper('chinaregion')->__('City'),
                'value'     => $model->getCityId(),
                'values'    => $optionsCity,
                'required'  => true,
                'disabled'  => false,
            ));
                
            $fieldset->addField('district_code', 'text', array(
                'name'      => 'district[code]',
                'label'     => Mage::helper('chinaregion')->__('Code'),
                'value'     => $model->getCode(),
                'required'  => true,
                'disabled'  => false,
            ));
            $fieldset->addField('default_name', 'text', array(
                'name'      => 'district[default_name]',
                'label'     => Mage::helper('chinaregion')->__('Default Name'),
                'value'     => $model->getDefaultName(),
                'required'  => true,
                'disabled'  => false,
            ));

            $fieldset->addField('locale_name', 'text', array(
                'name'      => 'district[locale_name]',
                'label'     => Mage::helper('chinaregion')->__('Locale Name').'('.$localeCode.')',
                'value'     => $model->getName(),
                'required'  => true,
                'disabled'  => false,
            ));
            $fieldset->addField('district_id', 'hidden', array(
                'name'      => 'district[district_id]',
                'no_span'   => true,
                'value'     => $model->getId()
            ));
           
        }

        $form->addField('region_type', 'hidden', array(
            'name'      => 'region_type',
            'no_span'   => true,
            'value'     => Mage::registry('region_type')
        ));

        $form->addField('region_action', 'hidden', array(
            'name'      => 'region_action',
            'no_span'   => true,
            'value'     => Mage::registry('region_action')
        ));

        $form->setAction($this->getUrl('*/*/save'));
        $form->setUseContainer(true);
        $this->setForm($form);

        return parent::_prepareForm();
    }
}
