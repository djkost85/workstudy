<?php
/**
 * Created by  Achang WebDev
 *
 * @copyright Achang WebDev
 * @link http://www.achang.com
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 *
 */


class Achang_ChinaRegion_Model_Mysql4_District_Collection extends Varien_Data_Collection_Db
{
    protected $_districtTable;
    protected $_districtNameTable;
    protected $_cityTable;

    public function __construct()
    {
        parent::__construct(Mage::getSingleton('core/resource')->getConnection('chinaregion_read'));

        $this->_cityTable    = Mage::getSingleton('core/resource')->getTableName('chinaregion/country_region_city');
        $this->_districtTable     = Mage::getSingleton('core/resource')->getTableName('chinaregion/country_region_city_district');
        $this->_districtNameTable = Mage::getSingleton('core/resource')->getTableName('chinaregion/country_region_city_district_name');

        $locale = Mage::app()->getLocale()->getLocaleCode();

        $this->_select->from(array('district'=>$this->_districtTable),
            array('district_id'=>'district_id', 'city_id'=>'city_id', 'code'=>'code', 'default_name'=>'default_name')
        );
        $this->_select->joinLeft(array('dname'=>$this->_districtNameTable),
            "district.district_id=dname.district_id AND dname.locale='$locale'", array('name'));

        $this->setItemObjectClass(Mage::getConfig()->getModelClassName('chinaregion/district'));
    }

    public function addCityFilter($cityId)
    {
        if (!empty($cityId)) {
            if (is_array($cityId)) {
                $this->addFieldToFilter('district.city_id', array('in'=>$cityId));
            } else {
                $this->addFieldToFilter('district.city_id', $cityId);
            }
        }
        return $this;
    }

    public function addCityCodeFilter($cityCode)
    {
        $this->_select->joinLeft(array('city'=>$this->_cityTable), 'district.city_id=city.city_id');
        $this->_select->where("city.code = '{$cityCode}'");
        return $this;
    }

    public function addDistrictCodeFilter($districtCode)
    {
        if (!empty($districtCode)) {
            if (is_array($districtCode)) {
                $this->_select->where("district.code IN ('".implode("','", $districtCode)."')");
            } else {
                $this->_select->where("district.code = '{$districtCode}'");
            }
        }
        return $this;
    }

    public function addDistrictNameFilter($districtName)
    {
        if (!empty($districtName)) {
            if (is_array($districtName)) {
                $this->_select->where("district.default_name in ('".implode("','", $districtName)."')");
            } else {
                $this->_select->where("district.default_name = '{$districtName}'");
            }
        }
        return $this;
    }

    public function toOptionArray()
    {
        $options = array();
        foreach ($this as $item) {
            $options[] = array(
               'value' => $item->getId(),
               'label' => $item->getName()
            );
        }
        if (count($options)>0) {
            array_unshift($options, array('title'=>null, 'value'=>'0', 'label'=>Mage::helper('chinaregion')->__('-- Please select --')));
        }
        return $options;
    }
}
