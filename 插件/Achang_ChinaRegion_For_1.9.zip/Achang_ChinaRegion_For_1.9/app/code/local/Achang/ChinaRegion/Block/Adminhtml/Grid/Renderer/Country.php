<?php
/**
 * Created by  Achang WebDev
 *
 * @copyright Achang WebDev
 * @link http://www.achang.com
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 *
 */



class Achang_ChinaRegion_Block_Adminhtml_Grid_Renderer_Country extends Mage_Adminhtml_Block_Tax_Rate_Grid_Renderer_Country
{
/**
     * Render column for export
     *
     * @param Varien_Object $row
     * @return string
     */
    public function renderExport(Varien_Object $row)
    {
        return $row->getData($this->getColumn()->getIndex());
    }
    
    /**
     * Render country grid column
     *
     * @param   Varien_Object $row
     * @return  string
     */
//    public function render(Varien_Object $row)
//    {
//    	$name = parent::render($row);
//    	if($name) {
//    		$name = '<a title="'.Mage::helper('core')->__('Edit Country').'" href="'.$this->getUrl('*/*/editCountry', array('country_id'=>$row->getCountryId())).'">' . $name . '</a>';
//    	}
//    	return $name;
//    }
}
