<?php

class Achang_News_Helper_Data extends Mage_Core_Helper_Abstract
{

}